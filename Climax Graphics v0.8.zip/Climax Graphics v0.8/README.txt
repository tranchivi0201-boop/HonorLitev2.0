Climax Graphics
Version 0.8 (released August 8, 2024)
Made by HonKit26113. All rights reserved.

This pack is only available on honkit26113.com & CurseForge / MCPEDL.

You may edit this add-on for personal use only.
Do not redistribute this add-on publicly in any way (whether edited or non-edited) without prior permission from the creator.


Changelog
Changes
 - Reduced saturation.
 - The sky is no longer dark during daytime.
 - Made the 3D effect of Grass Blocks more subtle.
 - Removed Lava and Flowing Lava point lights for better performance.
 - This pack now requires Minecraft *Preview* 1.21.30.22 or above to function.